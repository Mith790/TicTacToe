package tictacai;

/** Programmer:
 * Date:
 * Program Name: TicTacEvent.java
 * Program Description: This program runs the GUI for Tic Tac Toe
 */

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.JOptionPane;



public class TicTacEvent implements ItemListener, ActionListener, Runnable {
    TicTac gui;
    Thread playing;
    Thread playingAI;
    // Importing the images to be used
    ImageIcon a = new ImageIcon("x.png");
    ImageIcon b = new ImageIcon("o.png");
    ImageIcon c = new ImageIcon("versus.png");
    int clicks = 0;
    int win = 0;
    
    // Creating variables to keep track of different things
    int intXWins = 0; // Integer variable to keep track of how many times player X has won
    int intOWins = 0; // Integer variable to keep track of how many times player O has won
    int intTies = 0; // Integer variable to keep track of how many ties there were
    boolean isPlaying = false; // Boolean variable to keep track if game is still running
    boolean isRoundOver = false; // Boolean variable to keep track of if round is over
    boolean isEasyModeOn; // Boolean variable to keep track if AI is easy or hard
    boolean isPlayerX; // Boolean variable to keep track if first player is X or O
    boolean canPlay = false; // Boolean tracking if the AI Hard mode can play a good move
    int[][] check = new int[4][4];
    int intAIMoves = 0; // An integer variable to track how many moves the AI has made
    
    // Creating a boolean for if AI is active
    boolean isAIOn = false;
    
    // Creating a boolean variable for each card which states if its been clicked
    boolean isBtnOneSet = false, isBtnTwoSet = false, isBtnThreeSet = false, isBtnFourSet = false, isBtnFiveSet = false, isBtnSixSet = false,
            isBtnSevenSet = false, isBtnEightSet = false, isBtnNineSet = false, isBtnTenSet = false, isBtnElevenSet = false, isBtnTwelveSet = false,
            isBtnThirteenSet = false, isBtnFourteenSet = false, isBtnFifteenSet = false, isBtnSixteenSet = false;
        
    public TicTacEvent (TicTac in){
        gui = in;
        for (int row=0; row<=3; row++){
           for (int col=0; col<=3; col++){
               check[row][col]=0;
           }
       }
    }

    public void actionPerformed (ActionEvent event) {
       String command = event.getActionCommand();
       System.out.println("Clicks: " + clicks);
       if (command.equals("Play against Friend")) {           
           if ((isPlaying == false) && (win == 0)){
               startPlaying();
               // Allow user to choose if they want to play as X or O
               String[] strOptions = {"X", "O"}; // Array of options
               ImageIcon icon = new ImageIcon("cardback.jpg");
               String strDecision = (String)JOptionPane.showInputDialog(null, "Would the first player like to be X or O?",
                       "Player Selection", JOptionPane.QUESTION_MESSAGE, icon, strOptions, strOptions[1]);
               
               if (strDecision.equals("X")){
                   gui.txtMsg.setText("Player X's Turn");
                   isPlayerX = true;
               }
               else {
                   gui.txtMsg.setText("Player O's Turn");
                   isPlayerX = false;
                   // Swapping the x and o images
                   a = new ImageIcon("o.png");
                   b = new ImageIcon("x.png");
               }
               System.out.print(isPlayerX);
           }
           else {
               JOptionPane.showMessageDialog(null, "Currently playing with AI!\n(Click \"Start New Game\" to start new game)"); 
           }
       }
       if (command.equals("Play against AI")){
           if (isPlaying == false){  
               gui.txtMsg.setText("Player X's Turn");
               startPlayingAI();               
           }
           else{
               JOptionPane.showMessageDialog(null, "Currently playing with friend! \n(Click \"Start New Game\" to start new game)");               
           }             
       }
       if (command.equals("AI Easy Mode")){
           if ((isPlaying == false) && (isAIOn == true)){
              startPlayingEasyAI();
              
           } else if ((isEasyModeOn == false) && (isPlaying)){
               JOptionPane.showMessageDialog(null, "Currently playing against Hard AI! \n(Click \"Start New Game\" to start new game)"); 
           } else if (isPlaying == true){
               JOptionPane.showMessageDialog(null, "Currently playing with friend! \n(Click \"Start New Game\" to start new game)");     
           } else if (isAIOn == false){
               JOptionPane.showMessageDialog(null, "Please click \"Play against AI\" first");     
           } 
           
       }
       if (command.equals("AI Hard Mode")){
           if ((isPlaying == false) && (isAIOn == true)){
               startPlayingHardAI();
           } else if (isEasyModeOn == true){
               JOptionPane.showMessageDialog(null, "Currently playing against Easy AI! \n(Click \"Start New Game\" to start new game)"); 
           } else if (isPlaying == true){
               JOptionPane.showMessageDialog(null, "Currently playing with friend! \n(Click \"Start New Game\" to start new game)");     
           } else if (isAIOn == false){
               JOptionPane.showMessageDialog(null, "Please click \"Play against AI\" first");     
           } 
           
       }
       if (command.equals("Start New Round")){           
           resetRound();
       }
       if (command.equals("Start New Game")){
           resetGame();
       }
       // Only Accept other button clicks if the game has started and round is not over
       if((isPlaying) && (isRoundOver == false)){
       if (command.equals("1")) {
           b1();
           
       }
       if (command.equals("2")) {
           b2();
       }
       if (command.equals("3")) {
           b3();
       }
       if (command.equals("4")) {
           b4();
       }
       if (command.equals("5")) {
           b5();
       }
       if (command.equals("6")) {
           b6();
       }
       if (command.equals("7")) {
           b7();
       }
       if (command.equals("8")) {
           b8();
       }
       if (command.equals("9")) {
           b9();
       }
       if (command.equals("10")) {
           b10();
       }
       if (command.equals("11")) {
           b11();
       }
       if (command.equals("12")) {
           b12();
       }
       if (command.equals("13")) {
           b13();
       }
       if (command.equals("14")) {
           b14();
       }
       if (command.equals("15")) {
           b15();
       }
       if (command.equals("16")) {
           b16();
       }
       // Making sure that player turns are not outputted at the end of rounds
       if (isRoundOver == false){
           // Only displaying which player's turn it is if AI is turned off
           if(isAIOn == false){
           // Outputting which player's turn it is based on their prior selection
           if ((clicks % 2) == 1){
               if(isPlayerX){
                   gui.txtMsg.setText("Player O's Turn");
               } else {
                   gui.txtMsg.setText("Player X's Turn");
               }           
       } else {
               if (isPlayerX){
                   gui.txtMsg.setText("Player X's Turn");
               }else {
                   gui.txtMsg.setText("Player O's Turn");
               }           
       }
       }      
       }
    }
    
    }

    void b1() {
        if(isBtnOneSet == false){ // Only accept click if button is unclicked
        // Increasing clicks variable to the icon placed will be different next click
        clicks = clicks + 1;
        // If the clicks variable is odd, then the icon placed will be an X            
        if ((clicks % 2)==1){
            // Replacing the current image in the clicked box with an image of an X
            gui.boxes[0][0].setIcon(a);
            // Setting the value of the corresponding element in the check array to 1 to show it is an X
            check[0][0] = 1;
        // If the clicks variable is even, then the icon placed will be an O
        } else {
            // Replacing the current images in the clicked box with an image of an O
            gui.boxes[0][0].setIcon(b);
            // Setting the value of the corresponding element in the check array to 2 to show it is an O
            check[0][0] = 2;
        }
        winner();
        
        isBtnOneSet = true; // Changing variable to show button was clicked        
        // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){
                                  
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }         
               System.out.println("b1: " + intRandom);
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnTwoSet == false)){
                   gui.boxes[0][1].setIcon(b);
                   check[0][1] = 2;
                   isBtnTwoSet = true; // Changing variable to show button was chosen
               } else if ((intRandom == 2) && (isBtnSixSet == false)){
                   gui.boxes[1][1].setIcon(b);
                   check[1][1] = 2;
                   isBtnSixSet = true;
               } else if ((intRandom == 3) && (isBtnFiveSet == false)){
                   gui.boxes[1][0].setIcon(b);
                   check[1][0] = 2;
                   isBtnFiveSet = true;
               } else {
                   if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } 
                   // Blocking the diagonal
                   else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } 
                   // Blocking other possible wins
                   else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } 
                   // Trying to gain centre control
                   else if(isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } 
                   // If all above spot are taken, look for another spot starting with corners
                    else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   }                   
               }
               
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable               
           }           
        }              
        
               
    }
    void b2() {
        if(isBtnTwoSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[0][1].setIcon(a);
            check[0][1] = 1;
        } else {
            gui.boxes[0][1].setIcon(b);
            check[0][1] = 2;
        }
        winner();
        isBtnTwoSet = true; // Changing variable to show button was clicked 
        
        // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
                // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
               
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }         
               System.out.print("b2: " + intRandom);
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnThreeSet == false)){
                   gui.boxes[0][2].setIcon(b);
                   check[0][2] = 2;
                   isBtnThreeSet = true;
               } else if ((intRandom == 2) && (isBtnSixSet == false)){
                   gui.boxes[1][1].setIcon(b);
                   check[1][1] = 2;
                   isBtnSixSet = true;
               } else if ((intRandom == 3) && (isBtnOneSet == false)){
                   gui.boxes[0][0].setIcon(b);
                   check[0][0] = 2;
                   isBtnOneSet = true;
               } else {
                    if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;                    
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;
                   // Blocking possible wins
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   }                    
                    // Trying to gain centre control
                    else if(isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;
                   // If all above spots are taken, look for another spot starting with corners
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                       // Check if any other spots are free
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   }
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable                
           }
        }
    }
    void b3() {
        if(isBtnThreeSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[0][2].setIcon(a);
            check[0][2] = 1;
        } else {
            gui.boxes[0][2].setIcon(b);
            check[0][2] = 2;
        }
        winner();
        isBtnThreeSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
                   
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnTwoSet == false)){
                   gui.boxes[0][1].setIcon(b);
                   check[0][1] = 2;
                   isBtnTwoSet = true;
               } else if ((intRandom == 2) && (isBtnSevenSet == false)){
                   gui.boxes[1][2].setIcon(b);
                   check[1][2] = 2;
                   isBtnSevenSet = true;
               } else if ((intRandom == 3) && (isBtnFourSet == false)){
                   gui.boxes[0][3].setIcon(b);
                   check[0][3] = 2;
                   isBtnFourSet = true;
               } else {
                    if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;                    
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } 
                   // Blocking possible wins
                    else if(isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } 
                   // Trying to gain centre control
                    else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                    // If all above spots are taken, look for another spot starting with corners
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                       // Check if any other spots are free
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } 
               }
               
               }
               winner(); // Checking if AI won
               clicks += 1;  
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b4() {
        System.out.println("AI: " + isAIOn + "\nwin: " + win);
        
        if(isBtnFourSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[0][3].setIcon(a);
            check[0][3] = 1;
        } else {
            gui.boxes[0][3].setIcon(b);
            check[0][3] = 2;
        }
        winner();
        isBtnFourSet = true; // Changing variable to show button was clicked
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
                // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
                   System.out.println("canPlay: " + canPlay);
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){    
                                  
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }
               System.out.println("Int: " + intRandom);
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnThreeSet == false)){
                   gui.boxes[0][2].setIcon(b);
                   check[0][2] = 2;
                   isBtnThreeSet = true;
               } else if ((intRandom == 2) && (isBtnSevenSet == false)){
                   gui.boxes[1][2].setIcon(b);
                   check[1][2] = 2;
                   isBtnSevenSet = true;
               } else if ((intRandom == 3) && (isBtnEightSet == false)){
                   gui.boxes[1][3].setIcon(b);
                   check[1][3] = 2;
                   isBtnEightSet = true;
               } else {
                    if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;                    
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } 
                   // Blocking possible wins
                    else if(isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;                       
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } 
                   // Trying to gain centre control
                    else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   }  else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                    // If all above spot are taken, look for another spot starting with corners
                   }  else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } 
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;  
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b5() {
        if(isBtnFiveSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[1][0].setIcon(a);
            check[1][0] = 1;
        } else {
            gui.boxes[1][0].setIcon(b);
            check[1][0] = 2;
        }
        winner();
        isBtnFiveSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                     
               
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnOneSet == false)){
                   gui.boxes[0][0].setIcon(b);
                   check[0][0] = 2;
                   isBtnOneSet = true;
               } else if ((intRandom == 2) && (isBtnSixSet == false)){
                   gui.boxes[1][1].setIcon(b);
                   check[1][1] = 2;
                   isBtnSixSet = true;
               } else if ((intRandom == 3) && (isBtnNineSet == false)){
                   gui.boxes[2][0].setIcon(b);
                   check[2][0] = 2;
                   isBtnNineSet = true;
               } else {
                    if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } 
                   // Blocking possible wins
                    else if(isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } // Blocking other spots
                     else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;                       
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } 
                   // Trying to gain centre control
                    else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   }  else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;                    
                   } 
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
               
           }           
        }
    }
    void b6() {
        if(isBtnSixSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[1][1].setIcon(a);
            check[1][1] = 1;
        } else {
            gui.boxes[1][1].setIcon(b);
            check[1][1] = 2;
        }
        winner();
        isBtnSixSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
                 
               // Creating a random integer variable from 1 to 6 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 6)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnOneSet == false)){
                   gui.boxes[0][0].setIcon(b);
                   check[0][0] = 2;
                   isBtnOneSet = true;
               } else if ((intRandom == 2) && (isBtnTwoSet == false)){
                   gui.boxes[0][1].setIcon(b);
                   check[0][1] = 2;
                   isBtnTwoSet = true;
               } else if ((intRandom == 3) && (isBtnFiveSet == false)){
                   gui.boxes[1][0].setIcon(b);
                   check[1][0] = 2;
                   isBtnFiveSet = true;
               } else if ((intRandom == 4) && (isBtnSevenSet == false)){
                   gui.boxes[1][2].setIcon(b);
                   check[1][2] = 2;
                   isBtnSevenSet = true;
               } else if ((intRandom == 5) && (isBtnTenSet == false)){
                   gui.boxes[2][1].setIcon(b);
                   check[2][1] = 2;
                   isBtnTenSet = true;
               } else if ((intRandom == 6) && (isBtnElevenSet == false)){
                   gui.boxes[2][2].setIcon(b);
                   check[2][2] = 2;
                   isBtnElevenSet = true;
               } else {
                    if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } 
                   // Blocking possible wins
                    else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;                       
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   }  // Blocking other spots
                   else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   }  else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;                    
                   } 
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b7() {
        if(isBtnSevenSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[1][2].setIcon(a);
            check[1][2] = 1;
        } else {
            gui.boxes[1][2].setIcon(b);
            check[1][2] = 2;
        }
        winner();
        isBtnSevenSet = true; // Changing variable to show button was clicked
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
                    
               // Creating a random integer variable from 1 to 6 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 6)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnFourSet == false)){
                   gui.boxes[0][3].setIcon(b);
                   check[0][3] = 2;
                   isBtnFourSet = true;
               } else if ((intRandom == 2) && (isBtnThreeSet == false)){
                   gui.boxes[0][2].setIcon(b);
                   check[0][2] = 2;
                   isBtnThreeSet = true;
               } else if ((intRandom == 3) && (isBtnEightSet == false)){
                   gui.boxes[1][3].setIcon(b);
                   check[1][3] = 2;
                   isBtnEightSet = true;
               } else if ((intRandom == 4) && (isBtnSixSet == false)){
                   gui.boxes[1][1].setIcon(b);
                   check[1][1] = 2;
                   isBtnSixSet = true;
               } else if ((intRandom == 5) && (isBtnTenSet == false)){
                   gui.boxes[2][1].setIcon(b);
                   check[2][1] = 2;
                   isBtnTenSet = true;
               } else if ((intRandom == 6) && (isBtnElevenSet == false)){
                   gui.boxes[2][2].setIcon(b);
                   check[2][2] = 2;
                   isBtnElevenSet = true;
               } else {
                    if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;                    
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } 
                   // Blocking possible wins
                    else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;                       
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   }// Blocking other spots
                   else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   }   else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   }
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b8() {
        if(isBtnEightSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[1][3].setIcon(a);
            check[1][3] = 1;
        } else {
            gui.boxes[1][3].setIcon(b);
            check[1][3] = 2;
        }
        winner();
        isBtnEightSet = true; // Changing variable to show button was clicked
        
        // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
               
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnFourSet == false)){
                   gui.boxes[0][3].setIcon(b);
                   check[0][3] = 2;
                   isBtnFourSet = true;
               } else if ((intRandom == 2) && (isBtnSevenSet == false)){
                   gui.boxes[1][2].setIcon(b);
                   check[1][2] = 2;
                   isBtnSevenSet = true;
               } else if ((intRandom == 3) && (isBtnTwelveSet == false)){
                   gui.boxes[2][3].setIcon(b);
                   check[2][3] = 2;
                   isBtnTwelveSet = true;               
               } else {
                    if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;                    
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } 
                   // Blocking possible wins
                   else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } // Blockiing other spots
                   else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;                       
                   } else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   }  else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   }  else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                   }
                   
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b9() {
        if(isBtnNineSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks % 2)==1){
            gui.boxes[2][0].setIcon(a);
            check[2][0] = 1;
        } else {
            gui.boxes[2][0].setIcon(b);
            check[2][0] = 2;
        }
        winner();
        isBtnNineSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
               
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnFiveSet == false)){
                   gui.boxes[1][0].setIcon(b);
                   check[1][0] = 2;
                   isBtnFiveSet = true;
               } else if ((intRandom == 2) && (isBtnTenSet == false)){
                   gui.boxes[2][1].setIcon(b);
                   check[2][1] = 2;
                   isBtnTenSet = true;
               } else if ((intRandom == 3) && (isBtnThirteenSet == false)){
                   gui.boxes[3][0].setIcon(b);
                   check[3][0] = 2;
                   isBtnThirteenSet = true;               
               } else {
                    if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;                    
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } 
                   // Blocking possible wins
                   else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } // Blockiing other spots
                   else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;                       
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   }  else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                   }
                   
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b10() {
        if(isBtnTenSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[2][1].setIcon(a);
            check[2][1] = 1;
        } else {
            gui.boxes[2][1].setIcon(b);
            check[2][1] = 2;
        }
        winner();
        isBtnTenSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
               
               // Creating a random integer variable from 1 to 6 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 6)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnSixSet == false)){
                   gui.boxes[1][1].setIcon(b);
                   check[1][1] = 2;
                   isBtnSixSet = true;
               } else if ((intRandom == 2) && (isBtnNineSet == false)){
                   gui.boxes[2][0].setIcon(b);
                   check[2][0] = 2;
                   isBtnNineSet = true;
               } else if ((intRandom == 3) && (isBtnThirteenSet == false)){
                   gui.boxes[3][0].setIcon(b);
                   check[3][0] = 2;
                   isBtnThirteenSet = true;
               } else if ((intRandom == 4) && (isBtnSevenSet == false)){
                   gui.boxes[1][2].setIcon(b);
                   check[1][2] = 2;
                   isBtnSevenSet = true;
               } else if ((intRandom == 5) && (isBtnFourteenSet == false)){
                   gui.boxes[3][1].setIcon(b);
                   check[3][1] = 2;
                   isBtnFourteenSet = true;
               } else if ((intRandom == 6) && (isBtnElevenSet == false)){
                   gui.boxes[2][2].setIcon(b);
                   check[2][2] = 2;
                   isBtnElevenSet = true;
               } else {
                     if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   }  else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } 
                   else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } 
                   // Blocking possible wins
                    else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } // Blocking other spots
                    else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;                       
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;                    
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } 
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b11() {
        if(isBtnElevenSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[2][2].setIcon(a);
            check[2][2] = 1;
        } else {
            gui.boxes[2][2].setIcon(b);
            check[2][2] = 2;
        }
        winner();
        isBtnElevenSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
               
               // Creating a random integer variable from 1 to 6 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 6)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }
               System.out.print(intRandom);
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnSixteenSet == false)){
                   gui.boxes[3][3].setIcon(b);
                   check[3][3] = 2;
                   isBtnSixteenSet = true;
               } else if ((intRandom == 2) && (isBtnFifteenSet == false)){
                   gui.boxes[3][2].setIcon(b);
                   check[3][2] = 2;
                   isBtnFifteenSet = true;
               } else if ((intRandom == 3) && (isBtnTwelveSet == false)){
                   gui.boxes[2][3].setIcon(b);
                   check[2][3] = 2;
                   isBtnTwelveSet = true;
               } else if ((intRandom == 5) && (isBtnTenSet == false)){
                   gui.boxes[2][1].setIcon(b);
                   check[2][1] = 2;
                   isBtnTenSet = true;
               } else if ((intRandom == 4) && (isBtnSixSet == false)){
                   gui.boxes[1][1].setIcon(b);
                   check[1][1] = 2;
                   isBtnSixSet = true;
               } else if ((intRandom == 6) && (isBtnSevenSet == false)){
                   gui.boxes[1][2].setIcon(b);
                   check[1][2] = 2;
                   isBtnSevenSet = true;
               } else {
                    if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;                       
                   } 
                   
                   // Blocking possible wins
                    else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                     // Blocking other spots
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;                       
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;                    
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   }
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }
           
        }
    }
    void b12() {
        if(isBtnTwelveSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[2][3].setIcon(a);
            check[2][3] = 1;
        } else {
            gui.boxes[2][3].setIcon(b);
            check[2][3] = 2;
        }
        winner();
        isBtnTwelveSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
                 
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnSixteenSet == false)){
                   gui.boxes[3][3].setIcon(b);
                   check[3][3] = 2;
                   isBtnSixteenSet = true;
               } else if ((intRandom == 2) && (isBtnElevenSet == false)){
                   gui.boxes[2][2].setIcon(b);
                   check[2][2] = 2;
                   isBtnElevenSet = true;
               } else if ((intRandom == 3) && (isBtnEightSet == false)){
                   gui.boxes[1][3].setIcon(b);
                   check[1][3] = 2;
                   isBtnEightSet = true;               
               } else {
                    if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } 
                   // Blocking possible wins
                   else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;                    
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } // Blocking other spots
                   else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;                       
                   } else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                    
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   }  else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                   }                    
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }           
        }
    }
    void b13() {
        if(isBtnThirteenSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[3][0].setIcon(a);
            check[3][0] = 1;
        } else {
            gui.boxes[3][0].setIcon(b);
            check[3][0] = 2;
        }
        winner();
        isBtnThirteenSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
                   
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }       
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnFourteenSet == false)){
                   gui.boxes[3][1].setIcon(b);
                   check[3][1] = 2;
                   isBtnFourteenSet = true;
               } else if ((intRandom == 2) && (isBtnTenSet == false)){
                   gui.boxes[2][1].setIcon(b);
                   check[2][1] = 2;
                   isBtnTenSet = true;
               } else if ((intRandom == 3) && (isBtnNineSet == false)){
                   gui.boxes[2][0].setIcon(b);
                   check[2][0] = 2;
                   isBtnNineSet = true;
               } else {
                   if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } 
                   // Blocking possible wins
                   else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;
                   } else if(isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } // If all above spot are taken, look for another spot starting with corners
                    else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                   }             
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }       
        }
    }
    void b14() {
        if(isBtnFourteenSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[3][1].setIcon(a);
            check[3][1] = 1;
        } else {
            gui.boxes[3][1].setIcon(b);
            check[3][1] = 2;
        }
        winner();
        isBtnFourteenSet = true; // Changing variable to show button was clicked 
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
               
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }         
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnFifteenSet == false)){
                   gui.boxes[3][2].setIcon(b);
                   check[3][2] = 2;
                   isBtnFifteenSet = true;
               } else if ((intRandom == 2) && (isBtnTenSet == false)){
                   gui.boxes[2][1].setIcon(b);
                   check[2][1] = 2;
                   isBtnTenSet = true;
               } else if ((intRandom == 3) && (isBtnThirteenSet == false)){
                   gui.boxes[3][0].setIcon(b);
                   check[3][0] = 2;
                   isBtnThirteenSet = true;
               } else {
                    if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;                    
                   } // Blocking possible wins                   
                    else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;                       
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   }                    
                    // Trying to gain centre control
                    else if(isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;
                   // If all above spots are taken, look for another spot starting with corners
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } else if (isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;                   
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } 
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }
        }
    }
    void b15() {
        if(isBtnFifteenSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[3][2].setIcon(a);
            check[3][2] = 1;
        } else {
            gui.boxes[3][2].setIcon(b);
            check[3][2] = 2;
        }
        winner();
        isBtnFifteenSet = true; // Changing variable to show button was clicked
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move                   
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
                  
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnFourteenSet == false)){
                   gui.boxes[3][1].setIcon(b);
                   check[3][1] = 2;
                   isBtnFourteenSet = true;
               } else if ((intRandom == 2) && (isBtnElevenSet == false)){
                   gui.boxes[2][2].setIcon(b);
                   check[2][2] = 2;
                   isBtnElevenSet = true;
               } else if ((intRandom == 3) && (isBtnSixteenSet == false)){
                   gui.boxes[3][3].setIcon(b);
                   check[3][3] = 2;
                   isBtnSixteenSet = true;
               } else {
                    if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   } else if (isBtnSixteenSet == false){
                       gui.boxes[3][3].setIcon(b);
                       check[3][3] = 2;
                       isBtnSixteenSet = true;
                   } 
                   // Blocking possible wins
                    else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } 
                   // Trying to gain centre control
                    else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;
                   // If all above spots are taken, look for another spot starting with corners
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;
                   } else if(isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;
                   } else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;                    
                   } 
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }   
        }
    }
    void b16() {
        if(isBtnSixteenSet == false){ // Only accept click if button is unclicked
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[3][3].setIcon(a);
            check[3][3] = 1;
        } else {
            gui.boxes[3][3].setIcon(b);
            check[3][3] = 2;
        }
        winner();
        isBtnSixteenSet = true; // Changing variable to show button was clicked
        
           // Automating a responding move if AI is playing and player has not won yet
           if((isAIOn) && (win == 0)){
               intAIMoves += 1;
               // If hard mode is on, calling the method which makes a move for the AI
               if (isEasyModeOn == false){
                   hardAIMove(); // Use method to make Hard AI move
               }
               // Following actions will only occur if easy mode is on or if hard AI fails to play a better move
               if ((isEasyModeOn) || (canPlay == false)){                   
               
               // Creating a random integer variable from 1 to 3 to determine AI's move
               int intRandom = 0;
               while ((intRandom < 1) || (intRandom > 3)){
                   intRandom = (int)Math.round(Math.random() * 10);               
           }                        
               // AI will make one of three moves depending on the number which was chosen
               if ((intRandom == 1) && (isBtnFifteenSet == false)){
                   gui.boxes[3][2].setIcon(b);
                   check[3][2] = 2;
                   isBtnFifteenSet = true;
               } else if ((intRandom == 2) && (isBtnElevenSet == false)){
                   gui.boxes[2][2].setIcon(b);
                   check[2][2] = 2;
                   isBtnElevenSet = true;
               } else if ((intRandom == 3) && (isBtnTwelveSet == false)){
                   gui.boxes[2][3].setIcon(b);
                   check[2][3] = 2;
                   isBtnTwelveSet = true;
               } else {
                    if (isBtnFifteenSet == false){
                       gui.boxes[3][2].setIcon(b);
                       check[3][2] = 2;
                       isBtnFifteenSet = true;
                   } else if (isBtnElevenSet == false){
                       gui.boxes[2][2].setIcon(b);
                       check[2][2] = 2;
                       isBtnElevenSet = true;                       
                   }  else if (isBtnTwelveSet == false){
                       gui.boxes[2][3].setIcon(b);
                       check[2][3] = 2;
                       isBtnTwelveSet = true;
                   } 
                   // Blocking possible wins
                    else if (isBtnSixSet == false){
                       gui.boxes[1][1].setIcon(b);
                       check[1][1] = 2;
                       isBtnSixSet = true;                    
                   } else if (isBtnFourSet == false){
                       gui.boxes[0][3].setIcon(b);
                       check[0][3] = 2;
                       isBtnFourSet = true;                       
                   } else if (isBtnThirteenSet == false){
                       gui.boxes[3][0].setIcon(b);
                       check[3][0] = 2;
                       isBtnThirteenSet = true;
                   } else if(isBtnOneSet == false){
                       gui.boxes[0][0].setIcon(b);
                       check[0][0] = 2;
                       isBtnOneSet = true;
                   } else if (isBtnEightSet == false){
                       gui.boxes[1][3].setIcon(b);
                       check[1][3] = 2;
                       isBtnEightSet = true;
                   } else if (isBtnFourteenSet == false){
                       gui.boxes[3][1].setIcon(b);
                       check[3][1] = 2;
                       isBtnFourteenSet = true;
                   } 
                   // Trying to gain centre control
                   else if (isBtnTenSet == false){
                       gui.boxes[2][1].setIcon(b);
                       check[2][1] = 2;
                       isBtnTenSet = true;
                   } else if (isBtnSevenSet == false){
                       gui.boxes[1][2].setIcon(b);
                       check[1][2] = 2;
                       isBtnSevenSet = true;
                   } 
                    // If all above spots are taken, look for another spot starting with corners  
                    else if (isBtnFiveSet == false){
                       gui.boxes[1][0].setIcon(b);
                       check[1][0] = 2;
                       isBtnFiveSet = true;
                   } else if (isBtnNineSet == false){
                       gui.boxes[2][0].setIcon(b);
                       check[2][0] = 2;
                       isBtnNineSet = true;
                   } else if (isBtnThreeSet == false){
                       gui.boxes[0][2].setIcon(b);
                       check[0][2] = 2;
                       isBtnThreeSet = true;                    
                   } else if (isBtnTwoSet == false){
                       gui.boxes[0][1].setIcon(b);
                       check[0][1] = 2;
                       isBtnTwoSet = true;
                   } 
               }
               
           }
               winner(); // Checking if AI won
               clicks += 1;
               canPlay = false; // Resetting the canPlay boolean variable
           }   
        }
    }

    void winner() {
        /** Check rows for winner */
        
        for (int x=0; x<=3; x++){
            if ((check[x][0]==check[x][1])&&(check[x][0]==check[x][2]&&(check[x][0]==check[x][3]))) {
                if (check[x][0]==1) {
                    // Displaying winner depending on player's prior choice
                    if (isPlayerX){
                        JOptionPane.showMessageDialog(null, "X is the winner"); // Outputting that player X won                        
                        intXWins += 1; // Increasing the variable storing Player X's wins
                    } else {
                        JOptionPane.showMessageDialog(null, "O is the winner");                        
                        intOWins += 1; // Increasing the variable storing Player O's wins
                    }
                    win = 1;
                    isRoundOver = true; // Changing the boolean isRoundOver to true
                    gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
                } else if (check[x][0]==2){
                    // Displaying winner depending on player's prior choice
                    if (isPlayerX){
                        JOptionPane.showMessageDialog(null, "O is the winner");                    
                        intOWins += 1; // Increasing the variable storing Player O's wins
                    } else {
                        JOptionPane.showMessageDialog(null, "X is the winner"); // Outputting that player X won                        
                        intXWins += 1; // Increasing the variable storing Player X's wins
                    }                    
                    win = 1;                    
                    isRoundOver = true; // Changing the boolean isRoundOver to true
                    gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
                }
            }
        }

        /** Check columns for winner */
        for (int x=0; x<=3; x++){
            if ((check[0][x]==check[1][x])&&(check[0][x]==check[2][x])&&(check[0][x]==check[3][x])) {
                if (check[0][x]==1) {
                    // Displaying winner depending on player's prior choice
                    if (isPlayerX){
                        JOptionPane.showMessageDialog(null, "X is the winner"); // Outputting that player X won                        
                        intXWins += 1; // Increasing the variable storing Player X's wins
                    } else {
                        JOptionPane.showMessageDialog(null, "O is the winner");                        
                        intOWins += 1; // Increasing the variable storing Player O's wins
                    }
                    win = 1;
                    isRoundOver = true; // Changing the boolean isRoundOver to true
                    gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
                } else if (check[0][x]==2) {
                    // Displaying winner depending on player's prior choice
                    if (isPlayerX){
                        JOptionPane.showMessageDialog(null, "O is the winner");                    
                        intOWins += 1; // Increasing the variable storing Player O's wins
                    } else {
                        JOptionPane.showMessageDialog(null, "X is the winner"); // Outputting that player X won                        
                        intXWins += 1; // Increasing the variable storing Player X's wins
                    }                    
                    win = 1;                    
                    isRoundOver = true; // Changing the boolean isRoundOver to true
                    gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
                }                
            }
        }

        /** Check diagonals for winner */
        // 
        if (((check[0][0]!=0)&&(check[0][0]==check[1][1])&&(check[0][0]==check[2][2]))&&(check[0][0]==check[3][3])||
                ((check[3][0]!=0)&&(check[3][0]==check[2][1])&&(check[2][1]==check[1][2])&&(check[1][2]==check[0][3]))){
            if (((check[0][0] == 1) && (check[1][1] == 1) && (check[2][2] == 1)&& (check[3][3] == 1)) || 
                    ((check[0][3] == 1) && (check[1][2] == 1) && (check[2][1] == 1) && (check[3][0] == 1))){
                // Displaying winner depending on player's prior choice
                if (isPlayerX){
                    JOptionPane.showMessageDialog(null, "X is the winner"); // Outputting that player X won                        
                    intXWins += 1; // Increasing the variable storing Player X's wins
                } else {
                    JOptionPane.showMessageDialog(null, "O is the winner");                        
                    intOWins += 1; // Increasing the variable storing Player O's wins
                }
                win = 1;
                isRoundOver = true; // Changing the boolean isRoundOver to true
                gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
            } else if (((check[0][0] == 2) && (check[1][1] == 2) && (check[2][2] == 2)&& (check[3][3] == 2)) || 
                    ((check[0][3] == 2) && (check[1][2] == 2) && (check[2][1] == 2) && (check[3][0] == 2))){                
                // Displaying winner depending on player's prior choice
                if (isPlayerX){
                    JOptionPane.showMessageDialog(null, "O is the winner");                    
                    intOWins += 1; // Increasing the variable storing Player O's wins
                } else {
                    JOptionPane.showMessageDialog(null, "X is the winner"); // Outputting that player X won                        
                    intXWins += 1; // Increasing the variable storing Player X's wins
                }                    
                win = 1;      
                isRoundOver = true; // Changing the boolean isRoundOver to true
                gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
            }            
        }

        /** Checks if the game is a tie */
        if (isAIOn == false){
            if ((clicks==16) && (win==0)) {
            JOptionPane.showMessageDialog(null, "The game is a tie"); // Outputting that the game is a tie
            intTies += 1;
            isRoundOver = true; // Changing the boolean isRoundOver to true
            gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
        }
        } else {
            if ((intAIMoves == 8) && (win==0)) {
            JOptionPane.showMessageDialog(null, "The game is a tie"); // Outputting that the game is a tie
            intTies += 1;
            isRoundOver = true; // Changing the boolean isRoundOver to true
            gui.txtMsg.setText("Click on \"Start New Round\" or \"Start New Game\""); // Informing user what to do next
        }
        }
        if (isPlayerX){
            gui.blank1.setText("Player X Wins: " + intXWins); // Outputting the number of times player X won by changing text field
        if(isAIOn){
            gui.blank2.setText("AI Wins: " + intOWins); // Outputting the number of times the AI won by changing text field
        } else {
            gui.blank2.setText("Player O Wins: " + intOWins); // Outputting the number of times player O won by changing text field
        }        
        } else {
            gui.blank1.setText("Player O Wins: " + intOWins); // Outputting the number of times player X won by changing text field
        if(isAIOn){
            gui.blank2.setText("AI Wins: " + intXWins); // Outputting the number of times the AI won by changing text field
        } else {
            gui.blank2.setText("Player X Wins: " + intXWins); // Outputting the number of times player O won by changing text field
        }        
        }
        gui.txtTies.setText("Ties: " + intTies); // Outputting the number of ties by changing text field
    }

     
    void startPlaying() {
        playing = new Thread(this);
        playing.start();
        gui.play.setEnabled(false);
        // Changing the boolean variable tracking if game is playing to true
        isPlaying = true; // Setting isPlaying variable to true
    }
    
    // A method to determine if the user has chosen to play with AI by clicking the corresponding button
    void startPlayingAI() {
        playingAI = new Thread(this);
        playingAI.start();
        gui.btnPlayAI.setEnabled(false);
        // Changing the boolean variable tracking if game is playing to true
        //isPlaying = true; // Setting is Playing variable to true
        isAIOn = true; // Turning on AI mode
        win = 1; // Increasing win, so player can't play until they choose difficulty
        gui.txtMsg.setText("AI mode is on"); // Outputting the AI mode is on instead of which player's turn it is
        // Allow user to choose if they want to play as X or O
              String[] strOptions = {"X", "O"}; // Array of options
              ImageIcon icon = new ImageIcon("cardback.jpg");
              String strDecision = (String)JOptionPane.showInputDialog(null, "Would you like to be X or O?",
                    "Player Selection", JOptionPane.QUESTION_MESSAGE, icon, strOptions, strOptions[1]);
              // If user chooses to play as O, swapping the images and adjusting board
               if (strDecision.equals("O")){
                   // Swapping the x and o images
                   a = new ImageIcon("o.png");
                   b = new ImageIcon("x.png");
                   gui.blank1.setText("Player O Wins: 0"); // Outputting Player O score instead of Player X score
                   isPlayerX = false; // Changing boolean storing if Player is X to false
               } else {
                   a = new ImageIcon("x.png");
                   b = new ImageIcon("o.png");
                   gui.blank1.setText("Player X Wins: 0"); // Outputting Player X score instead of Player O score
                   isPlayerX = true; // Changing boolean storing if Player is X to true
               }
        JOptionPane.showMessageDialog(null, "Please choose \"AI Easy Mode\" or \"AI Hard Mode\""); // Prompting user to choose difficult
    }
    // A method to start the easy mode of AI
    void startPlayingEasyAI(){
        //isAIOn = true; // Turning on AI mode
        win = 0; // Making this 0 so player can now click buttons
        isEasyModeOn = true; // Turning on easy mode
        gui.btnEasyMode.setEnabled(false);
        gui.txtMsg.setText("AI Easy mode is on"); // Outputting the AI mode is on instead of which player's turn it is
        isPlaying = true; // Setting is Playing variable to true
    }
    // A method to start the hard mode of AI
    void startPlayingHardAI(){
       //isAIOn = true; // Turning on AI mode
       win = 0; // Making this 0 so player can now click buttons
       isEasyModeOn = false; // Turning on easy mode
       gui.btnHardMode.setEnabled(false);
       gui.txtMsg.setText("AI Hard mode is on"); // Outputting the AI mode is on instead of which player's turn it is
       isPlaying = true; // Setting is Playing variable to true
    }
    // Method which decides Hard AI's move    
    void hardAIMove(){
        // First the AI will check every row for winning opportunities as winning is the priority
       
        int intPlacements = 0; // Integer tracking how many of the AI's symbol exists in a row or column
        // Checking first row
        intPlacements = rowCheck(0, 2);
       // If there are three in the first row, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[0][col] != 2){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[0][col] = 2;
               gui.boxes[0][col].setIcon(b);
               if (intTemp == 0){
                   isBtnOneSet = true;
               } else if (intTemp == 1){
                   isBtnTwoSet = true;
               } else if (intTemp == 2){
                   isBtnThreeSet = true;
               } else {
                   isBtnFourSet = true;
               }
           }            
       }
        return; // In this case, the AI has won, so the method may end
       }
       
       // Checking second row
       intPlacements = rowCheck(1, 2);
       // If there are three in the second row, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[1][col] != 2){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[1][col] = 2;
               gui.boxes[1][col].setIcon(b);
               if (intTemp == 0){
                   isBtnFiveSet = true;
               } else if (intTemp == 1){
                   isBtnSixSet = true;
               } else if (intTemp == 2){
                   isBtnSevenSet = true;
               } else {
                   isBtnEightSet = true;
               }
           }            
       }
        return; // In this case, the AI has won, so the method may end
       }
              
       // Checking third row
       intPlacements = rowCheck(2, 2);
       // If there are three in the third row, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[2][col] != 2){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[2][col] = 2;
               gui.boxes[2][col].setIcon(b);
               if (intTemp == 0){
                   isBtnNineSet = true;
               } else if (intTemp == 1){
                   isBtnTenSet = true;
               } else if (intTemp == 2){
                   isBtnElevenSet = true;
               } else {
                   isBtnTwelveSet = true;
               }
           }           
       }
        return; // In this case, the AI has won, so the method may end
       }
       
       // Checking fourth/last row
       intPlacements = rowCheck(3, 2);
       // If there are three in the fourth row, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[3][col] != 2){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[3][col] = 2;
               gui.boxes[3][col].setIcon(b);
               if (intTemp == 0){
                   isBtnThirteenSet = true;
               } else if (intTemp == 1){
                   isBtnFourteenSet = true;
               } else if (intTemp == 2){
                   isBtnFifteenSet = true;
               } else {
                   isBtnSixteenSet = true;
               }
           }           
       }
        return; // In this case, the AI has won, so the method may end
       }
       
       // Checking the diagonals to see if AI can win
       // Now checking for winning opportunities in the top left to bottom right diagonal
       intPlacements = firstDiagonalCheck(2);
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the diagonal
           for (int row = 0; row <= 3; row++){
               for (int col = 0; col <= 3; col++){
                   if (((row == 0) && (col == 0)) || ((row == 1) && (col == 1)) || ((row == 2) && (col == 2)) || ((row == 3) && (col == 3))){
                       if (check[row][col] != 2){
                           int intTemp = col; // Creating a temporary int to make correct button unclickable
                           check[row][col] = 2;
                           gui.boxes[row][col].setIcon(b);
                           if (intTemp == 0){
                               isBtnOneSet = true;
                           } else if (intTemp == 1){
                               isBtnSixSet = true;
                           } else if (intTemp == 2){
                               isBtnElevenSet = true;
                           } else {
                               isBtnSixteenSet = true;
                           }
                       }
                   }
               }
           }
           return; // Int this case, the AI has won, so the method may end
       }
       
       // Now checking for winning opportunities in the top right to bottom left diagonal
       intPlacements = secondDiagonalCheck(2);
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the diagonal
           for (int row = 0; row <= 3; row++){
               for (int col = 3; col >= 0; col--){
                   if (((row == 0) && (col == 3)) || ((row == 1) && (col == 2)) || ((row == 2) && (col == 1)) || ((row == 3) && (col == 0))){
                       if (check[row][col] != 2){
                           int intTemp = col; // Creating a temporary int to make correct button unclickable
                           check[row][col] = 2;
                           gui.boxes[row][col].setIcon(b);
                           if (intTemp == 0){
                               isBtnThirteenSet = true;
                           } else if (intTemp == 1){
                               isBtnTenSet = true;
                           } else if (intTemp == 2){
                               isBtnSevenSet = true;
                           } else {
                               isBtnFourSet = true;
                           }
                       }
                   }
               }
           }
           return; // Int this case, the AI has won, so the method may end
       }
       // Now the AI will check every column for winning opportunities
       // Checking first column
       intPlacements = columnCheck(0, 2);
       // If there are three in the first column, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][0] != 2){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][0] = 2;
                   gui.boxes[row][0].setIcon(b);
                   if (intTemp == 0){
                       isBtnOneSet = true;
                   } else if (intTemp == 1){
                       isBtnFiveSet = true;
                   } else if (intTemp == 2){
                       isBtnNineSet = true;
                   } else{
                       isBtnThirteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end           
       }
       
       // Checking second column
       intPlacements = columnCheck(1, 2);
       // If there are three in the second column, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][1] != 2){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][1] = 2;
                   gui.boxes[row][1].setIcon(b);
                   if (intTemp == 0){
                       isBtnTwoSet = true;
                   } else if (intTemp == 1){
                       isBtnSixSet = true;
                   } else if (intTemp == 2){
                       isBtnTenSet = true;
                   } else{
                       isBtnFourteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end
       }
       
       // Checking third column
       intPlacements = columnCheck(2, 2);
       // If there are three in the third column, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][2] != 2){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][2] = 2;
                   gui.boxes[row][2].setIcon(b);
                   if (intTemp == 2){
                       isBtnThreeSet = true;
                   } else if (intTemp == 1){
                       isBtnSevenSet = true;
                   } else if (intTemp == 2){
                       isBtnElevenSet = true;
                   } else{
                       isBtnFifteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end
       }
       
       // Checking fourth/last column
       intPlacements = columnCheck(3, 2);
       // If there are three in the fourth column, place the last symbol
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][3] != 2){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][3] = 2;
                   gui.boxes[row][3].setIcon(b);
                   if (intTemp == 0){
                       isBtnFourSet = true;
                   } else if (intTemp == 1){
                       isBtnEightSet = true;
                   } else if (intTemp == 2){
                       isBtnTwelveSet = true;
                   } else{
                       isBtnSixteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end
       }
       

       // If all of the above does not result in anything, the AI cannot win this turn
       // Now it will attempt to block any potential wins from the user
       // First it will check if the user can win from any row
       // Checking first row
       intPlacements = rowCheck(0, 1);
       // If there are three in the first row, block the last place
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[0][col] != 1){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[0][col] = 2;
               gui.boxes[0][col].setIcon(b);
               if (intTemp == 0){
                   isBtnOneSet = true;
               } else if (intTemp == 1){
                   isBtnTwoSet = true;
               } else if (intTemp == 2){
                   isBtnThreeSet = true;
               } else {
                   isBtnFourSet = true;
               }
           }            
       }
        return; // In this case, the AI has has played its move, so the method may end
       }
       
       // Checking second row
       intPlacements = rowCheck(1, 1);
       // If there are three in the second row, block the last place
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[1][col] != 1){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[1][col] = 2;
               gui.boxes[1][col].setIcon(b);
               if (intTemp == 0){
                   isBtnFiveSet = true;
               } else if (intTemp == 1){
                   isBtnSixSet = true;
               } else if (intTemp == 2){
                   isBtnSevenSet = true;
               } else {
                   isBtnEightSet = true;
               }
           }            
       }
        return; // In this case, the AI has has played its move, so the method may end
       }
       
       // Checking third row
       intPlacements = rowCheck(2, 1);
       // If there are three in the third row, block the last place
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[2][col] != 1){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[2][col] = 2;
               gui.boxes[2][col].setIcon(b);
               if (intTemp == 0){
                   isBtnNineSet = true;
               } else if (intTemp == 1){
                   isBtnTenSet = true;
               } else if (intTemp == 2){
                   isBtnElevenSet = true;
               } else {
                   isBtnTwelveSet = true;
               }
           }            
       }
        return; // In this case, the AI has has played its move, so the method may end
       }
       
       // Checking fourth/last row
       intPlacements = rowCheck(3, 1);
       // If there are three in the fourth row, block the last place
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the row
           for (int col = 0; col <= 3; col++){
           if (check[3][col] != 1){
               int intTemp = col; // Creating a temporary int to make correct button unlickable
               check[3][col] = 2;
               gui.boxes[3][col].setIcon(b);
               if (intTemp == 0){
                   isBtnThirteenSet = true;
               } else if (intTemp == 1){
                   isBtnFourteenSet = true;
               } else if (intTemp == 2){
                   isBtnFifteenSet = true;
               } else {
                   isBtnSixteenSet = true;
               }
           }            
       }        
        return; // In this case, the AI has has played its move, so the method may end
       }
       
       // Checking the diagonals to see if user can win
       // Now checking for winning opportunities in the top left to bottom right diagonal
       intPlacements = firstDiagonalCheck(1);
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the diagonal
           for (int row = 0; row <= 3; row++){
               for (int col = 0; col <= 3; col++){
                   if (((row == 0) && (col == 0)) || ((row == 1) && (col == 1)) || ((row == 2) && (col == 2)) || ((row == 3) && (col == 3))){
                       if (check[row][col] != 1){
                           int intTemp = col; // Creating a temporary int to make correct button unclickable
                           check[row][col] = 2;
                           gui.boxes[row][col].setIcon(b);
                           if (intTemp == 0){
                               isBtnOneSet = true;
                           } else if (intTemp == 1){
                               isBtnSixSet = true;
                           } else if (intTemp == 2){
                               isBtnElevenSet = true;
                           } else {
                               isBtnSixteenSet = true;
                           }
                       }
                   }
               }
           }
           return; // Int this case, the AI has played its move, so the method may end
       }
       
       // Now checking for winning opportunities in the top right to bottom left diagonal
       intPlacements = secondDiagonalCheck(1);
       if (intPlacements == 3){
           canPlay = true;
           // Placing the last symbol needed in the diagonal
           for (int row = 0; row <= 3; row++){
               for (int col = 3; col >= 0; col--){
                   if (((row == 0) && (col == 3)) || ((row == 1) && (col == 2)) || ((row == 2) && (col == 1)) || ((row == 3) && (col == 0))){
                       if (check[row][col] != 1){
                           int intTemp = col; // Creating a temporary int to make correct button unclickable
                           check[row][col] = 2;
                           gui.boxes[row][col].setIcon(b);
                           if (intTemp == 0){
                               isBtnThirteenSet = true;
                           } else if (intTemp == 1){
                               isBtnTenSet = true;
                           } else if (intTemp == 2){
                               isBtnSevenSet = true;
                           } else {
                               isBtnFourSet = true;
                           }
                       }
                   }
               }
           }
           return; // Int this case, the AI has won, so the method may end
       }
       
       // Now the AI will check every column to see if user can win
       // Checking first column
       intPlacements = columnCheck(0, 1);
       // If there are three in the first column, block the last spot
       if (intPlacements == 3){
           canPlay = true;
           // Blocking the last spot in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][0] != 1){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][0] = 2;
                   gui.boxes[row][0].setIcon(b);
                   if (intTemp == 0){
                       isBtnOneSet = true;
                   } else if (intTemp == 1){
                       isBtnFiveSet = true;
                   } else if (intTemp == 2){
                       isBtnNineSet = true;
                   } else{
                       isBtnThirteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end           
       }
       
       // Checking second column
       intPlacements = columnCheck(1, 1);
       // If there are three in the second column, block the last spot
       if (intPlacements == 3){
           canPlay = true;
           // Blocking the last spot in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][1] != 1){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][1] = 2;
                   gui.boxes[row][1].setIcon(b);
                   if (intTemp == 0){
                       isBtnTwoSet = true;
                   } else if (intTemp == 1){
                       isBtnSixSet = true;
                   } else if (intTemp == 2){
                       isBtnTenSet = true;
                   } else{
                       isBtnFourteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end
       }
       
       // Checking third column
       intPlacements = columnCheck(2, 1);
       // If there are three in the third column, block the last spot
       if (intPlacements == 3){
           canPlay = true;
           // Blocking the last spot in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][2] != 1){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][2] = 2;
                   gui.boxes[row][2].setIcon(b);
                   if (intTemp == 2){
                       isBtnThreeSet = true;
                   } else if (intTemp == 1){
                       isBtnSevenSet = true;
                   } else if (intTemp == 2){
                       isBtnElevenSet = true;
                   } else{
                       isBtnFifteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end
       }
       
       // Checking fourth/last column
       intPlacements = columnCheck(3, 1);
       // If there are three in the fourth column, block the last spot
       if (intPlacements == 3){
           canPlay = true;
           // Blcking the last spot in the column
           for (int row = 0; row <= 3; row++){
               if (check[row][3] != 1){
                   int intTemp = row; // Creating a temporary int to make correct button unclickable
                   check[row][3] = 2;
                   gui.boxes[row][3].setIcon(b);
                   if (intTemp == 0){
                       isBtnFourSet = true;
                   } else if (intTemp == 1){
                       isBtnEightSet = true;
                   } else if (intTemp == 2){
                       isBtnTwelveSet = true;
                   } else{
                       isBtnSixteenSet = true;
                   }
               }
           }
           return; // In this case, the AI has won, so the method may end
       }
    }

    // Method to check if there are 3 symbols in the same row
    /**
     * 
     * @param row is the parameter for which row the method will check
     * @param symbol is the parameter for if it is an AI symbol or user symbol (either 1 or 2)
     * @returns the integer intPlacements which stores how many times the symbol appears in the row
     */
    public int rowCheck(int row, int symbol){
        // First the AI will check every row for winning opportunities as winning is the priority        
        int intPlacements = 0; // Local integer variable tracking how many of the AI's symbol exists in a row
        boolean isRowFull = true; // Local boolean variable to check if row is full
        // Checking given row
        for (int col = 0; col <= 3; col++){
            if (check[row][col] == symbol){
                intPlacements += 1;
               }
            if (check[row][col] == 0){
                isRowFull = false;
               } 
       }
       if (isRowFull){
           intPlacements = 0; // To ensure that intPlacements is not equal to three if row is full
       }   
    return intPlacements;
    }
    
    // Method to check if the AI has 3 symbols in the same column
    /**
     * 
     * @param col is the parameter for which column the method will check
     * @param symbol is the parameter for if it is an AI symbol or user symbol (either 1 or 2)
     * @returns the integer intPlacements which stores how many times the symbol appears in the column
     */
    public int columnCheck(int col, int symbol){
        // First the AI will check every column for winning opportunities as winning is the priority
        int intPlacements = 0; // Local integer variable tracking how many of the AI's symbol exists in a column
        boolean isColumnFull = true; // Local boolean variable to check if column is full
        // Checking given column
        for (int row = 0; row <= 3; row++){
            if (check[row][col] == symbol){
                intPlacements += 1;
               }
            if (check[row][col] == 0){
                isColumnFull = false;
               } 
        }
        if (isColumnFull){
            intPlacements = 0; // To ensure that intPlacements is not equal to three if column is ful
        }
    return intPlacements;
    }
    
    // Method to check if the AI has 3 symbols in the same diagonal (top left to bottom right)    
    /**
     * 
     * @param symbol is the parameter for if it is an AI symbol or user symbol (either 1 or 2)
     * @returns the integer intPlacements which stores how many times the symbol appears in the diagonal
     */
    public int firstDiagonalCheck(int symbol){
        // The AI will check if there is any winning possibility in the top left to bottom right diagonal first
        int intPlacements = 0; // Local integer variable tracking how many of the AI's symbol exists in the diagonal
        boolean isDiagonalFull = true; // Local boolean variable to check if diagonal is full
        for(int row = 0; row<= 3; row++){
            for(int col = 0; col<= 3; col++){
                if (((row == 0) && (col == 0)) || ((row == 1) && (col == 1)) || ((row == 2) && (col == 2)) || ((row == 3) && (col == 3))){
                    if (check[row][col] == symbol){
                        intPlacements += 1;
                    }
                    if (check[row][col] == 0){
                        isDiagonalFull = false;
                    }
                }
            }
        }
        if (isDiagonalFull){
            intPlacements = 0; // To ensure that intPlacements is not equal to three if diagonal is full
        }
        return intPlacements;
    }
    
    // Method to check if the AI has 3 symbols in the same diagonal (top right to bottom left)
    public int secondDiagonalCheck(int symbol){
        // The AI will check if there is any winning possibility in the top left to bottom right diagonal first
        int intPlacements = 0; // Local integer variable tracking how many of the AI's symbol exists in the digonal
        boolean isDiagonalFull = true; // Local boolean variable to check if the diagonal is full
        for(int row = 0; row<= 3; row++){
            for(int col = 3; col >= 0; col--){
                if (((row == 0) && (col == 3)) || ((row == 1) && (col == 2)) || ((row == 2) && (col == 1)) || ((row == 3) && (col == 0))){
                    if (check[row][col] == symbol){
                        intPlacements += 1;
                    }
                    if (check[row][col] == 0){
                        isDiagonalFull = false;
                    }
                }
            }
        }
        if (isDiagonalFull){
            intPlacements = 0; // To ensure that intPlacements is not equal to three is diagonal is full
        }
        return intPlacements;
    }
    
    // Method to reset round
    void resetRound(){        
        // Resetting the check array
        for (int row = 0; row <= 3; row++){
           for (int col = 0; col <= 3; col++){
               check[row][col] = 0;
           }
       }
       // Setting all the buttons to false so they will respond to clicks again
       isBtnOneSet = false; 
       isBtnTwoSet = false; 
       isBtnThreeSet = false; 
       isBtnFourSet = false; 
       isBtnFiveSet = false; 
       isBtnSixSet = false;
       isBtnSevenSet = false; 
       isBtnEightSet = false; 
       isBtnNineSet = false;
       isBtnTenSet = false; 
       isBtnElevenSet = false; 
       isBtnTwelveSet = false;
       isBtnThirteenSet = false; 
       isBtnFourteenSet = false;
       isBtnFifteenSet = false;
       isBtnSixteenSet = false;
       
       // Resetting the images on the cards
       for (int x=0; x<=3; x++){
           for (int y=0; y<=3; y++){                
                gui.boxes[x][y].setIcon(c);                
            }
        }
       
       // Resetting the appropriate variables
       clicks = 0;
       win = 0;
       isRoundOver = false;       
       canPlay = false;
       intAIMoves = 0;
    }
    
    // Method to reset game
    void resetGame(){
        // Resetting everthing which is reset at the end of a round
        resetRound();
        
        // Resetting the score keeping variable as well
        intXWins = 0;
        intOWins = 0;
        intTies = 0;
        
        // Changing the isPlaying variable back to false
        isPlaying = false;
        
        // Resetting player variable
        isPlayerX = true;
        
        // Changing the isAIOn back to false to deactivate AI mode
        isAIOn = false;
        isEasyModeOn = false;
        
        // Enabling all buttons
        gui.play.setEnabled(true);
        gui.btnPlayAI.setEnabled(true);
        gui.btnEasyMode.setEnabled(true);
        gui.btnHardMode.setEnabled(true);
        
        // Resetting all the statements being outputted
        gui.blank1.setText("Player X Wins: " + intXWins);
        gui.blank2.setText("");
        gui.txtTies.setText("Ties: " + intTies);
        gui.txtMsg.setText("Click on \"Play against Friend\" or \"Play against AI\" to start ");
        
        // Resetting images
        a = new ImageIcon("x.png");
        b = new ImageIcon("o.png");
    }

    public void itemStateChanged(ItemEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void run() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}

