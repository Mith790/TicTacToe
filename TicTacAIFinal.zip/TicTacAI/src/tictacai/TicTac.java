package tictacai;

import java.awt.*;
import javax.swing.*;

public class TicTac extends JFrame {
    TicTacEvent tictac = new TicTacEvent(this);
    TicTacEvent tictacAI = new TicTacEvent(this);
    TicTacEvent newRound = new TicTacEvent(this);

    JPanel row1 = new JPanel();
    JPanel row2 = new JPanel(); // Creating a new panel for the output message
    JButton[][] boxes = new JButton[4][4];
    JButton play = new JButton("Play against Friend"); // A button to play with friend
    JButton btnPlayAI = new JButton ("Play against AI"); // A button to play with AI
    JButton btnNewRound = new JButton ("Start New Round"); // A button to start a new round
    JButton btnNewGame = new JButton ("Start New Game"); // A button to start over
    JButton btnEasyMode = new JButton ("AI Easy Mode"); // A button to play against easy AI
    JButton btnHardMode = new JButton ("AI Hard Mode"); // A button to play against hard AI
    JTextField blank1 = new JTextField();
    JTextField blank2 = new JTextField();
    JTextField txtMsg = new JTextField("Click on \"Play against Friend\" or \"Play against AI\" to start "); // A text field to communicate with user
    JTextField txtTies = new JTextField("The Objective is to get four of your symbols in a row"); // A text field to output the number of ties thus far
    JOptionPane win = new JOptionPane("Winner");
    ImageIcon back = new ImageIcon("versus.png");

    public TicTac() {
        super ("Tic Tac Toe");
        // Setting the program to a size which can display a 4 by 4 board
        setSize (750, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FlowLayout layout = new FlowLayout();
        setLayout(layout);
        
        int name = 0;
        String newname;
        
        // Setting the fonts of the display boxes
        blank1.setFont(new Font ("Helvetica", Font.BOLD, 17));
        blank2.setFont(new Font ("Helvetica", Font.BOLD, 17));
        
        // Creating the grid layout such that there are 5 rows, 4 columns and the gaps between are 10 spaces
        GridLayout layout1 = new GridLayout(5, 4, 10, 10);
        row1.setLayout(layout1);
        for (int x=0; x<=3; x++){
            for (int y=0; y<=3; y++){
                name = name + 1;
                newname = Integer.toString(name);
                boxes[x][y] = new JButton();
                boxes[x][y].setActionCommand(newname);
                boxes[x][y].setIcon(back);
                row1.add(boxes[x][y]);
            }
        }
        row1.add(blank1);
        row1.add(play);
        row1.add(btnPlayAI); // Adding the button to play with AI
        row1.add(blank2);
        add (row1);
        
        // Adding the new round button
        add(btnNewRound);
        
        // Changing the font and font size of the message text field
        txtMsg.setFont(new Font ("Helvetica", Font.BOLD, 15));
        // Adding the text field to the JFrame
        add(txtMsg);       

        // Adding the new game button
        add(btnNewGame);
        
        // Adding a button to choose easy AI difficulty
        add(btnEasyMode);
        
        // Adjusting the font of and then adding the text field to show the amount of ties
        txtTies.setFont(new Font ("Helvetica", Font.BOLD, 15));
        add(txtTies);
        
        // Adding a button to choose hard difficulty       
        add(btnHardMode);
        
        
        play.addActionListener(tictac);
        for (int x=0; x<=3; x++){
            for (int y=0; y<=3; y++){
                boxes[x][y].addActionListener(tictac);
            }
        }
        
        btnPlayAI.addActionListener(tictac);
        
        btnNewRound.addActionListener(tictac);
        btnNewGame.addActionListener(tictac);
        btnEasyMode.addActionListener(tictac);
        btnHardMode.addActionListener(tictac);

        setVisible(true);
    }

    public static void main(String[] arguments){
        TicTac frame = new TicTac();
    }
}